# Bildquellen

- ring.jpg: https://unsplash.com/photos/1605100804763-247f67b3557e (CDN photo-1605100804763-247f67b3557e)
- watch.jpg: https://images.unsplash.com/photo-1524805444758-089113d48a6d
- jewel.jpg: https://images.unsplash.com/photo-1603561591411-07134e71a2a9
- earrings.jpg: https://images.unsplash.com/photo-1535632066927-ab7c9ab60908
- necklace.jpg: https://images.unsplash.com/photo-1599643477877-530eb83abc8e
- craft.jpg: https://images.pexels.com/photos/6263063/pexels-photo-6263063.jpeg
- hero.mp4: https://videos.pexels.com/video-files/6262753/6262753-hd_1920_1080_25fps.mp4
- poster.jpg: Standbild des Herovideos

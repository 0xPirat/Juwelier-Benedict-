# Juwelier Benedict

Heller, responsiver erster Shopentwurf mit Home, Schmuck, Uhren und Geschichte.

## Ausführen

Den Ordner `dist` mit einem statischen Webserver bereitstellen, z. B. `python -m http.server 8080 --directory dist`.

## Stand

- Full-HD-Herovideo (1920 × 1080), Poster, Pause und reduzierte Bewegung
- Scrollabhängiger Header, mobile Navigation
- Kategoriefilter, Produktvorschau, lokale Merkliste
- Alle Produkte, Bilder und Titel sind Gestaltungsbeispiele. Keine Verkaufsangebote, Zahlung oder Bestellannahme.
- Anbieterangaben, Datenschutz, echte Kontaktinformationen und Verkaufsbedingungen vor öffentlichem Verkaufsstart ergänzen.

## Inhalt ändern

`dist/app.js`: Geschichte, Produktdaten und Seiteninhalt. `dist/style.css`: Gestaltung. `dist/assets`: Bilder und Video.

## Referenzen und Medien

Gestaltungsrecherche: https://www.wempe.com/de-de/ und https://www.bucherer.com/de/de . Keine Markenmedien übernommen.

Video: Tima Miroshnichenko / Pexels, https://www.pexels.com/video/close-up-shot-of-a-diamond-ring-6262753/
Handwerksbild: Pexels, https://www.pexels.com/photo/6263063/
Weitere Beispielbilder: Unsplash (Foto-IDs stehen in `ASSETS.md`). Alle Medien sind nur Platzhalter und zeigen keine tatsächlichen Bestandsstücke oder Familienmitglieder.

Die Merkliste speichert nur Beispiel-IDs lokal auf dem verwendeten Gerät. Google Fonts wird extern geladen.
